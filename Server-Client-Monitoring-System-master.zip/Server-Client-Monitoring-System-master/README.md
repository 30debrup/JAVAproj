# Server-Client-Monitoring-System
A Java Project for network based message monitoring.

This project "Server Client Monitoring System" provides us a simple interface for implementing fundamental technical functionalities in an organization . It can be used by educational institutes or colleges to run laboratory sessions easily and effectively. Achieving
this objective is tedious job using traditional approach of practical sessions. This traditional approach is time consuming and not much effective. All these problems are solved using this project.

Throughout the project the focus has been on presenting a software in an easy and intelligible manner.

The project provides facilities like sharing mails and sharing display of teacher’s monitor with student monitors during practical sessions and displaying information from college server on any computer in college without transferring any file.
